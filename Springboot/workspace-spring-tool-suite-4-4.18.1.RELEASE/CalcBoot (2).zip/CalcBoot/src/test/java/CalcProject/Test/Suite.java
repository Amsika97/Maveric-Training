package CalcProject.Test;

public @interface Suite {

}
