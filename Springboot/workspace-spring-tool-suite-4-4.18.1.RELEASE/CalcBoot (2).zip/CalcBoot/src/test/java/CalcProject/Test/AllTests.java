package CalcProject.Test;

import org.junit.runners.Suite.SuiteClasses;

@Suite
@SuiteClasses({ Caltest1.class, Caltest2.class })
public class AllTests {

}
